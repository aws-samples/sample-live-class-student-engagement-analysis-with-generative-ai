import json
import jwt
import uuid
import time
import os

def lambda_handler(event, context):
    username = event.get('username', 'testUser')
    email = event.get('email', 'testuser@ugc.com')
    
    user_pool_id = "us-west-2_ltsO2yCFd"
    client_id = "2mofe91ndi37m9gf9pbqdvfui6"

    # Mock token expiration time (e.g., 1 hour)
    current_time = int(time.time())
    exp = current_time + 3600  # Token expires in 1 hour

    # Payload for the access token
    access_token_payload = {
        'sub': str(uuid.uuid4()),
        'iss': f'https://cognito-idp.us-west-2.amazonaws.com/{user_pool_id}',
        'client_id': client_id,
        'origin_jti': str(uuid.uuid4()),
        'event_id': str(uuid.uuid4()),
        'token_use': 'access',
        'scope': 'aws.cognito.signin.user.admin',
        'auth_time': current_time,
        'exp': exp,
        'iat': current_time,
        'jti': str(uuid.uuid4()),
        'username': username
    }

    # Generate the access token
    access_token = jwt.encode(access_token_payload, 'mock-access-token-secret', algorithm='HS256')

    # Generate the ID token
    id_token_payload = {
        'sub': access_token_payload['sub'],
        'email': email,
    }
    id_token = jwt.encode(id_token_payload, 'mock-id-token-secret', algorithm='HS256')

    # Generate the refresh token
    refresh_token_payload = {
        'sub': access_token_payload['sub'],
    }
    refresh_token = jwt.encode(refresh_token_payload, 'mock-refresh-token-secret', algorithm='HS256')

    return {
        'statusCode': 200,
        'body': json.dumps({
            'access_token': access_token,
            'id_token': id_token,
            'refresh_token': refresh_token
        })
    }

# Example usage:
# To test the Lambda function, you can create a test event in the AWS console like this:
# {
#   "username": "your_username",
#   "email": "your_email@example.com"
# }

